# DBSN Project Roadmap

**Version:** 1.0  
**Last Updated:** 2026-05-22  
**Status:** Phase 2 - Core Features (In Progress)

---

## Overview

This roadmap tracks the implementation of the DBSN Centralized Digital Ecosystem — a hub-and-spoke architecture consolidating three legacy WordPress domains into a single Next.js 15 codebase.

### Architecture Summary

- **Hub:** `sentradaya.com` — Corporate trust center
- **Spokes:** `pju.sentradaya.com`, `solarcell.sentradaya.com`, `alatpetir.sentradaya.com`, `baterai.sentradaya.com`
- **Dashboard:** `dashboard.sentradaya.com` — Client tracking portal
- **Tech Stack:** Next.js 15, Sanity.io, Neon Postgres + Prisma, Auth.js v5, Cloudflare Pages

---

## Phase 1: Foundation (COMPLETED)

### Status: ✅ COMPLETE

### Objectives

Establish the project foundation with Next.js 15, TypeScript, and shared design system.

### Tasks

| Task | Status | Date Completed |
|------|--------|----------------|
| Initialize Next.js 15 with TypeScript | ✅ | 2026-05-13 |
| Configure pnpm package manager | ✅ | 2026-05-13 |
| Set up Tailwind CSS 4 + design tokens | ✅ | 2026-05-13 |
| Configure Radix UI + shadcn/ui patterns | ✅ | 2026-05-13 |
| Set up Prisma ORM configuration | ✅ | 2026-05-13 |
| Configure Jest testing framework | ✅ | 2026-05-13 |
| Environment variables structure | ✅ | 2026-05-13 |

### Success Criteria

- ✅ Next.js app runs locally on `pnpm dev`
- ✅ Tailwind CSS configured with DBSN design tokens
- ✅ Jest runs with 80% coverage threshold
- ✅ TypeScript strict mode enabled

---

## Phase 2: Core Features (IN PROGRESS)

### Status: 🔄 86% COMPLETE (6/7 tasks)

### Objectives

Build hub pages, spoke pages, RFQ forms, and authentication system.

### Tasks

| Task | Status | Owner | Date |
|------|--------|-------|------|
| 2.1 Route Groups Structure | ✅ | ECC | 2026-05-19 |
| 2.2 Shared UI Components | ✅ | ECC | 2026-05-19 |
| 2.3 Hub Pages | ✅ | ECC | 2026-05-19 |
| 2.4 Spoke Pages | ✅ | ECC | 2026-05-19 |
| 2.5 RFQ Forms (B2G/B2B) | ⏳ PARTIAL | ECC | (Form components + Zod schemas done. API endpoint, notifications, fallback pending) |
| 2.6 Sanity CMS Integration | ✅ | ECC | 2026-05-21 |
| 2.7 Subdomain Middleware | ✅ | ECC | 2026-05-22 |

### Phase 2.5: Segmented RFQ Forms (PARTIAL)

**Description:** Implement B2G and B2B RFQ forms with proper validation and submission handling.

**Tasks:**
- ✅ Create B2G form component with government-specific fields
- ✅ Create B2B form component with private sector fields
- ✅ Implement Zod validation schemas
- ⏳ Add WhatsApp fallback engine
- ⏳ Create `/api/rfq` endpoint
- ⏳ Implement source attribution tracking

**Success Criteria:**
- Forms validate input with clear error messages
- RFQ submissions persist to Neon Postgres
- Resend acknowledgment email sent on success
- Telegram alert triggered on submission
- WhatsApp fallback activates on API failure

**Blocked By:** None (Phase 2.7 is complete)

### Phase 2.6: Sanity CMS Integration (COMPLETE)

**Description:** Set up Sanity.io for content federation across hub and spokes.

**Note:** Review: REQUEST CHANGES — bugfixes pending (see [sanity-cms-review.md](file:///d:/CLAUDE-PROJECT/website/.claude/reviews/sanity-cms-review.md))

**Tasks:**
- ✅ Configure Sanity client
- ✅ Define content schemas (Product, Certification, PortfolioEntry, SpokeConfig)
- ✅ Implement GROQ query utilities
- ✅ Set up webhook-based cache invalidation
- ✅ Connect spoke pages to CMS data

**Success Criteria:**
- Product data fetches from Sanity
- Certification documents accessible
- Portfolio entries display correctly
- Webhook invalidates cache on content changes

### Phase 2.7: Subdomain Middleware (COMPLETE)

**Description:** Implement middleware-based routing for hub, spokes, and dashboard.

**Note:** Review: APPROVED — 155/155 tests passing (see [subdomain-middleware-review.md](file:///d:/CLAUDE-PROJECT/website/.claude/reviews/subdomain-middleware-review.md))

**Tasks:**
- ✅ Create `middleware.ts` file
- ✅ Implement hostname-based routing logic
- ✅ Add subdomain-to-route-group mapping
- ✅ Configure local subdomain testing (lvh.me)
- ✅ Add authentication guards for dashboard

**Code Reference (Expected):**

```typescript
// middleware.ts
export function middleware(request: NextRequest) {
  const hostname = request.headers.get('host')?.split(':')[0] || '';

  if (hostname === 'sentradaya.com') {
    return NextResponse.rewrite(new URL('/', request.url));
  }

  if (hostname === 'pju.sentradaya.com') {
    return NextResponse.rewrite(new URL('/(spokes)/pju', request.url));
  }

  if (hostname === 'dashboard.sentradaya.com') {
    return NextResponse.rewrite(new URL('/(dashboard)', request.url));
  }

  return NextResponse.next();
}
```

**Success Criteria:**
- Hub routes correctly via `sentradaya.com`
- Spokes route correctly via their subdomains
- Dashboard routes correctly via `dashboard.sentradaya.com`
- Local testing works with `lvh.me`

---

## Phase 3: Infrastructure (NOT STARTED)

### Status: ⏸️ NOT STARTED

### Objectives

Set up deployment infrastructure, integrations, and SEO migration engine.

### Tasks

| Task | Status | Priority |
|------|--------|----------|
| 3.1 Notification Queue Implementation | ⏳ TODO | P0 |
| 3.2 Cloudflare Pages Deployment | ⏳ TODO | P0 |
| 3.3 301 Redirect Engine | ⏳ TODO | P0 |
| 3.4 SEO Migration | ⏳ TODO | P0 |
| 3.5 GA4 Event Tracking | ⏳ TODO | P1 |
| 3.6 GSC Verification | ⏳ TODO | P1 |

### Success Criteria

- Cloudflare Pages deploys successfully
- Legacy URLs 301 redirect to new architecture
- Zero 404s for indexed legacy URLs during migration
- GA4 events fire for RFQ submissions, WhatsApp clicks, file downloads

---

## Phase 4: Quality Gates (NOT STARTED)

### Status: ⏸️ NOT STARTED

### Objectives

Performance optimization, security hardening, testing coverage, and production readiness.

### Tasks

| Task | Status | Target |
|------|--------|--------|
| 4.1 PSI 90+ Optimization | ⏳ TODO | Mobile PSI ≥ 90 |
| 4.2 Security Hardening | ⏳ TODO | CSP, HSTS, input validation |
| 4.3 Test Coverage 80%+ | ⏳ TODO | Unit, Integration, E2E |
| 4.4 RFQ Fallback Testing | ⏳ TODO | Forced failure test |
| 4.5 Dashboard Access Testing | ⏳ TODO | Data isolation verification |
| 4.6 Production Deployment | ⏳ TODO | Go/no-go approval |

### Success Criteria

- PSI mobile score 90+ on all key templates
- 80%+ code coverage with passing tests
- Security scan passes with no critical findings
- RFQ fallback validated under forced failure
- Dashboard data isolation confirmed

---

## Launch Gate Checklist

### Pre-Launch Requirements

- [ ] All Phase 1-4 tasks complete
- [ ] PSI mobile score 90+ on all key pages
- [ ] 80%+ test coverage passing
- [ ] Security audit passed
- [ ] SEO migration mapping complete
- [ ] 301 redirect engine tested
- [ ] RFQ fallback forced-failure test passed
- [ ] Dashboard access provisioning tested
- [ ] Stakeholder presentation delivered
- [ ] Go/no-go approval from leadership

### Rollback Conditions

Trigger rollback if any of the following occur:
- Production uptime < 99.5% for 1 hour
- >20% of requests return 404 errors
- Critical failure in RFQ pipeline > 1 hour
- Security incident confirmed
- Performance degradation > 50%

---

## Glossary

| Term | Definition |
|------|------------|
| **Hub** | Root domain `sentradaya.com` — corporate trust center |
| **Spoke** | Product subdomains (`pju.*`, `solarcell.*`, etc.) |
| **B2G** | Business-to-Government segment (procurement officers, PPK, BUMN) |
| **B2B** | Business-to-Business segment (private sector buyers) |
| **RFQ** | Request for Quotation — segmented form for lead capture |
| **PSI** | PageSpeed Insights — Google's performance measurement tool |

---

## Related Documentation

- [PRD v3.1](../prd/prd-v3.md) — Business requirements and user journeys
- [TDD v1](../architecture/tdd-v1.md) — Technical design and implementation
- [CLAUDE.md](../../../../CLAUDE.md) — Project context and architecture
- [Local Setup](./local-setup.md) — Development environment configuration
- [Mocking Specs](../testing/mocking-specs.md) — Testing patterns for external services

---

*Last modified: 2026-05-22*